﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pyramid.Test
{
    public interface ITestInterface1
    {
        void WriteInterface1Method();
    }

    public interface ITestInterface2
    {
        void WriteInterface2Method();
    }
}