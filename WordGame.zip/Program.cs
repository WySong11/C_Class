﻿using System;

namespace WordGame
{
    public class Program
    {
        static void Main(string[] args)
        {
            GameDataManager.Instance.LoadGameDataListFromCSV();

            // JSON 파일에서 저장된 게임 데이터를 로드합니다.  
            GameDataManager.Instance.LoadSaveDataListFromJSON();

            GameDataManager.Instance.PrintGameDataList();
        }
    }
}
