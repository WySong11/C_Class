using System;
using System.Text;
using System.Globalization;

namespace StringLecture
{
    /// <summary>
    /// C# 문자열(String) 기초 예제 콘솔 프로그램
    /// - 초보자용으로 중요한 개념과 메서드를 한 번에 실습할 수 있도록 구성했습니다.
    /// - Visual Studio 2022 Community에서 "콘솔 앱"(.NET 6 이상)으로 새 프로젝트 생성 후
    ///   Program.cs 내용을 이 파일로 교체하고 실행해보세요.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Section("문자열 기초");
            Basics();

            Section("문자열 이어붙이기 + 보간(Interpolation)");
            ConcatAndInterpolation();

            Section("이스케이프 시퀀스와 @ 문자열(Verbatim)");
            EscapesAndVerbatim();

            Section("null, 빈 문자열, 공백만 있는 문자열");
            NullEmptyWhitespace();

            Section("자주 쓰는 문자열 메서드");
            CommonMethods();

            Section("부분 문자열 • 나누기(Split) • 합치기(Join)");
            SubstringSplitJoin();

            Section("치환(Replace)와 불변성(Immutability)");
            ReplaceAndImmutability();

            Section("비교(대소문자 구분/무시)");
            Comparisons();

            Section("많이 이어붙일 땐 StringBuilder");
            StringBuilderDemo();

            Section("형식 지정 출력: 숫자/날짜/통화");
            FormattingExamples();

            Console.WriteLine();
            Console.WriteLine("[엔터 키를 누르면 종료합니다]");
            Console.ReadLine();
        }

        static void Section(string title)
        {
            Console.WriteLine();
            Console.WriteLine(new string('=', 60));
            Console.WriteLine(title);
            Console.WriteLine(new string('-', 60));
        }

        // 1) 문자열 기초
        static void Basics()
        {
            string name = "Jaei";
            char letter = 'A'; // char는 한 글자

            Console.WriteLine($"name: {name}");
            Console.WriteLine($"첫 글자: {name[0]}");
            Console.WriteLine($"길이(Length): {name.Length}");

            // 문자열은 참조형(Reference Type)이고, 변경 불가능(Immutable)합니다.
        }

        // 2) 이어붙이기 & 보간
        static void ConcatAndInterpolation()
        {
            string hello = "Hello";
            string target = "World";
            string withPlus = hello + " " + target + "!";
            string withConcat = string.Concat(hello, " ", target, "!!");
            int year = DateTime.Now.Year;

            Console.WriteLine(withPlus);
            Console.WriteLine(withConcat);
            Console.WriteLine($"문자열 보간 사용: {hello} {target}! {year}년 입니다.");
        }

        // 3) 이스케이프, Verbatim
        static void EscapesAndVerbatim()
        {
            string lines = "첫째줄\n둘째줄\t(탭)\n큰따옴표는 이렇게 표현: \"안녕\"";
            Console.WriteLine(lines);

            // Windows 경로 표현: \ 문자를 그대로 쓰려면 @ 사용
            string path = @"C:\Users\Jaei\Documents\project";
            Console.WriteLine(path);

            string multiLine = @"여러 줄도
그대로
보여줍니다.";
            Console.WriteLine(multiLine);
        }

        // 4) null/empty/whitespace
        static void NullEmptyWhitespace()
        {
            string a = null;       // 값이 없음
            string b = "";         // 빈 문자열(길이 0)
            string c = "   ";      // 공백만 있음

            Console.WriteLine($"IsNullOrEmpty(null): {string.IsNullOrEmpty(a)}");
            Console.WriteLine($"IsNullOrEmpty(\"\"): {string.IsNullOrEmpty(b)}");
            Console.WriteLine($"IsNullOrWhiteSpace(\"   \"): {string.IsNullOrWhiteSpace(c)}");
        }

        // 5) 자주 쓰는 메서드
        static void CommonMethods()
        {
            string text = "  Unity, C#, String Basics  ";
            Console.WriteLine($"원본: '{text}'");
            Console.WriteLine($"Trim(): '{text.Trim()}'");
            Console.WriteLine($"ToUpper(): {text.ToUpper()}");
            Console.WriteLine($"ToLower(): {text.ToLower()}");
            Console.WriteLine($"Contains(\"C#\"): {text.Contains("C#")}");
            Console.WriteLine($"StartsWith(\"  Uni\"): {text.StartsWith("  Uni")}");
            Console.WriteLine($"EndsWith(\"Basics  \"): {text.EndsWith("Basics  ")}");
            Console.WriteLine($"IndexOf('y'): {text.IndexOf('y')}");

            // 안전한 범위 체크 후 인덱싱
            if (text.Length > 5)
            {
                Console.WriteLine($"5번째 문자: '{text[4]}'");
            }
        }

        // 6) Substring / Split / Join
        static void SubstringSplitJoin()
        {
            string email = "jaei@example.com";
            int at = email.IndexOf('@');
            string id = email.Substring(0, at);
            string domain = email.Substring(at + 1);
            Console.WriteLine($"이메일: {email} → ID: {id}, 도메인: {domain}");

            string csv = "sword,potion,shield";
            string[] items = csv.Split(',');
            Console.WriteLine("Split 결과: " + string.Join(" | ", items));

            string joined = string.Join(", ", items);
            Console.WriteLine("Join 결과: " + joined);
        }

        // 7) Replace와 불변성
        static void ReplaceAndImmutability()
        {
            string original = "banana";
            string replaced = original.Replace("na", "NA");

            Console.WriteLine($"original: {original}");  // 그대로
            Console.WriteLine($"replaced: {replaced}");  // 변경된 새 문자열
        }

        // 8) 비교
        static void Comparisons()
        {
            string s1 = "Unity";
            string s2 = "unity";

            Console.WriteLine($"Equals(대소문자 구분): {s1.Equals(s2)}");
            Console.WriteLine($"Equals(대소문자 무시): {s1.Equals(s2, StringComparison.OrdinalIgnoreCase)}");

            // 포함 검사도 대소문자 무시
            Console.WriteLine($"\"Unity\"에 \"UNI\"가 포함?(무시): {s1.Contains("UNI", StringComparison.OrdinalIgnoreCase)}");
        }

        // 9) StringBuilder
        static void StringBuilderDemo()
        {
            var sb = new StringBuilder();
            for (int i = 1; i <= 5; i++)
            {
                sb.Append(i).Append(", ");
            }
            // 끝의 ", " 제거
            string result = sb.ToString().TrimEnd(',', ' ');
            Console.WriteLine($"StringBuilder 결과: {result}");
        }

        // 10) 형식 지정
        static void FormattingExamples()
        {
            double ratio = 0.12345;
            int number = 1234567;
            DateTime now = DateTime.Now;

            Console.WriteLine(string.Format("백분율(P1): {0:P1}", ratio));
            Console.WriteLine($"세 자리 콤마(N0): {number:N0}");
            Console.WriteLine($"날짜 포맷: {now:yyyy-MM-dd HH:mm:ss}");

            var ko = new CultureInfo("ko-KR");
            Console.WriteLine(string.Format(ko, "통화(C0): {0:C0}", 19800));
        }
    }
}
