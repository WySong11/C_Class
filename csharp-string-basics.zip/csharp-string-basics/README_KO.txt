# C# 문자열(String) 기초 예제 실행 방법

- Visual Studio 2022 Community를 실행합니다.
- 새 프로젝트 만들기에서 "콘솔 앱" (.NET 6 이상)을 선택합니다.
- 프로젝트가 생성되면 Program.cs 파일의 모든 코드를 지우고, 이 저장소의 Program.cs 내용으로 교체합니다.
- 빌드 후 실행합니다.
- 콘솔에 각 섹션의 출력이 순서대로 표시됩니다.

## 파일 설명
- Program.cs : 문자열 기초를 한 파일에서 실습할 수 있는 예제 코드입니다.

## 학습 포인트
- 문자열 선언/길이/인덱싱
- 이어붙이기(+, Concat)와 문자열 보간($"{expr}")
- 이스케이프와 Verbatim(@) 문자열
- null/empty/whitespace 구분과 검사
- 자주 쓰는 메서드: Trim/ToUpper/Contains/StartsWith/EndsWith/IndexOf
- 부분 문자열(SubString), 나누기(Split), 합치기(Join)
- Replace와 불변성(원본 보존)
- 비교(대소문자 구분/무시)와 StringComparison
- StringBuilder로 반복 이어붙이기
- 형식 지정 출력(숫자/날짜/통화)
